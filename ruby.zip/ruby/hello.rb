puts("o world")

class Spelling_Checker
    def initialize()
        @words = ['catt', "ct", 'caaat','tcat']
    end

       def spellChecker(string)
          array = string.split(" ")
              x=0
              array.each{ |n|
                if @words.include? n
                   a = array.index(n)
                   array[a]="*#{n}*"
#                    array.gsub(n,"*#{n}*")

                end
                x=x+1
              }.join(" ")
          end
        end

checker = Spelling_Checker.new
output = checker.spellChecker("catt")
p output

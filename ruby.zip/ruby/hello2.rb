array = ['catt', 'ct', 'caaat', 'tcat']
array.each{|n|
      print(n)}

names = ['Bob', 'Joe', 'Steve', 'Janice']

names.each { |name| puts name }


x = 1

names.each do |name|
  puts "*#{x}. #{name}*"
  x += 1
end

string = "Bob a"
a = string.split(" ")
print a

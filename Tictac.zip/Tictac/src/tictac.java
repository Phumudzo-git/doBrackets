import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class tictac {
    static ArrayList<Integer> humanLocations = new ArrayList<Integer>();
    static ArrayList<Integer> computerLocations = new ArrayList<Integer>();
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        char[][] grid = {{' ','|',' ','|',' '},
        		         {'-','+','-','+','-'},
        		         {' ','|',' ','|',' '},
        		         {'-','+','-','+','-'},
        		         {' ','|',' ','|',' '}};
     
        showGrid(grid);
        
        while(true) {
        	Scanner input = new Scanner(System.in);
            
            System.out.println("Place a number between 1 and 9");
            
            int inputNumber = input.nextInt();
            System.out.println(inputNumber);
            while(humanLocations.contains(inputNumber)||computerLocations.contains(inputNumber)) {
            	 inputNumber = input.nextInt();
            	 System.out.println("humanLoc");
            	
            }
            
            enterPosition(grid, "human", inputNumber);
            
            String results = winner();
            results  = winner();
            if(results.length()>0) {
            	System.out.println(results);
            	break;
            }            
            
            
            Random rand = new Random();
            int randomNumber = rand.nextInt(9)+1;
            while(humanLocations.contains(randomNumber)||computerLocations.contains(randomNumber)) {
            	 randomNumber = rand.nextInt(9)+1;
            	 System.out.println("compLoc");
            }
            
            enterPosition(grid, "computer", randomNumber);
            
            
            
            
            showGrid(grid);
            
            results = winner();
            if(results.length()>0) {
            	System.out.println(results);
            	break;
            }
        	
        }
                    	 
	 }
	
	public static void showGrid(char[][] grid) {
        for(char[] i: grid) {
        	for(char j: i) {
        		System.out.print(j);
        	};
        	System.out.println();
     }
        
     }
	
	public static void enterPosition(char[][] grid, String playerType, int inputNumber) {
		char sign = ' ';
		
	    if(playerType.equals("human")) {
	    	sign = 'x';
	    	humanLocations.add(inputNumber);
	    }
	    else if(playerType.equals("computer")) {
	    	sign = 'o';
	    	computerLocations.add(inputNumber);
	    }
		
		switch(inputNumber) {
        case 1:
        	grid[0][0]=sign;
        	break;
        case 2: 
        	grid[0][2]=sign;
        	break;
        case 3:
        	grid[0][4]=sign;
        	break;
        case 4: 
        	grid[2][0]=sign;
        	break;
        case 5:
        	grid[2][2]=sign;
        	break;
        case 6: 
        	grid[2][4]=sign;
        	break;
        case 7:
        	grid[4][0]=sign;
        	break;
        case 8: 
        	grid[4][2]=sign;
        	break;
        case 9:
        	grid[4][4]=sign;
        	break;
        }		
	}
	
	public static String winner() {
		List row1 = Arrays.asList(1,2,3);
		List row2 = Arrays.asList(4,5,6);
		List row3 = Arrays.asList(7,8,9);
		List col1 = Arrays.asList(1,4,7);
		List col2 = Arrays.asList(2,5,8);
		List col3 = Arrays.asList(3,6,9);
		List diag1 = Arrays.asList(1,5,9);
		List diag2 = Arrays.asList(3,5,7);	
		
		List<List> matrix = new ArrayList<List>();
		
		matrix.add(row1);
		matrix.add(row2);
		matrix.add(row3);
		matrix.add(col1);
		matrix.add(col2);
		matrix.add(col3);
		matrix.add(diag1);
		matrix.add(diag2);
		
		for(List i: matrix) {
			if(humanLocations.containsAll(i)) {
				return("Human wins");
			}else if(computerLocations.containsAll(i)) {
			    return"Computer Wins";
			}else if(computerLocations.size()+humanLocations.size()==9) {
				return("Tie");
			}
		}
		
		return "";
	}

}


